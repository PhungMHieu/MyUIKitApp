//
//  ProfileVC.swift
//  2025_06_24v1
//
//  Created by iKame Elite Fresher 2025 on 24/6/25.
//

import UIKit

class ProfileVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Profile"
        navigationController?.navigationBar.titleTextAttributes=[
            .foregroundColor: UIColor.neutral1,
            .font: UIFont.boldSystemFont(ofSize: 20)
        ]
        let backItem = UIBarButtonItem()
        backItem.title = "Quay lại"
//            backItem.tintColor = .red  // tuỳ chỉnh màu
        navigationItem.backBarButtonItem = backItem
        // Do any additional setup after loading the view.
    }
    @IBAction func AddButton(_ sender: UIButton) {
        let informationVC = InformationVC()
        navigationController?.pushViewController(informationVC, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
