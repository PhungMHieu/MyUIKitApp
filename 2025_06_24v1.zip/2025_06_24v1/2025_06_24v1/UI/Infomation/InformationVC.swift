//
//  InformationVC.swift
//  2025_06_24v1
//
//  Created by iKame Elite Fresher 2025 on 24/6/25.
//

import UIKit
protocol InformationDelegate{
    func update(_ result: Information)
}
class InformationVC: UIViewController {
    weak var delegate: InformationDelegate?
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var height: UITextField!
    @IBOutlet weak var weight: UITextField!
    @IBOutlet weak var gender: UISegmentedControl!
    @IBOutlet weak var lastName: UITextField!
//    @IBOutlet weak var firstName: UIView!
//    @IBOutlet weak var updateButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Information"
        let firstName = firstName.text ?? ""
        let lastName = lastName.text ?? ""
        let height = height.text ?? ""
        let weight = weight.text ?? ""
        let genderIndex = gender.selectedSegmentIndex
        let genderTitle = gender.titleForSegment(at: genderIndex) ?? ""
        let fullName = "\(firstName)   \(lastName)";
//        let info = Information(fullName, gender, height, weight)
        if let heightValue = Double(height), let weightValue = Double(weight){
            let info = Information(fullName: fullName, gender: genderTitle, height: heightValue, weight: weightValue)
        }
        
        // Do any additional setup after loading the view.
    }

    @IBAction func updateButton(_ sender: UIButton) {
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
