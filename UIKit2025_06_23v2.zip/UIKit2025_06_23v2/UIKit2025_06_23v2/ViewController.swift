//
//  ViewController.swift
//  UIKit2025_06_23v2
//
//  Created by Admin on 23/6/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

