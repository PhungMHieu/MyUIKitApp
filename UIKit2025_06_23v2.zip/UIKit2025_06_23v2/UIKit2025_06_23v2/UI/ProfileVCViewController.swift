//
//  ProfileVCViewController.swift
//  UIKit2025_06_23v2
//
//  Created by Admin on 23/6/25.
//

import UIKit

class ProfileVCViewController: UIViewController {
    
    @IBOutlet weak var BMIResult: UITextField!
    @IBOutlet weak var WeightResult: UITextField!
    @IBOutlet weak var GenderResult: UITextField!
    @IBOutlet weak var HeightResult: UITextField!
    @IBOutlet weak var FullNameResult: UITextField!
    @IBOutlet weak var Weight: UITextField!
    @IBOutlet weak var Height: UITextField!
    @IBOutlet weak var Gender: UISegmentedControl!
    @IBOutlet weak var LastName: UITextField!
    @IBOutlet weak var FirstName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func showResult(_ sender: UIButton) {
       let firstName = FirstName.text ?? ""
       let lastName = LastName.text ?? ""
       let height = Height.text ?? ""
       let weight = Weight.text ?? ""
       let genderIndex = Gender.selectedSegmentIndex
       let genderTitle = Gender.titleForSegment(at: genderIndex) ?? ""

       // 2. Gán vào các trường kết quả
       FullNameResult.text = "\(firstName) \(lastName)"
       HeightResult.text = "\(height) cm"
       WeightResult.text = "\(weight) kg"
       GenderResult.text = genderTitle
        // Validate số
           guard let height = Double(height), let weight = Double(weight) else {
               showAlert(message: "Vui lòng nhập số hợp lệ cho chiều cao và cân nặng.")
               BMIResult.text = "N/A"
               return
           }

           // Kiểm tra khoảng giá trị hợp lệ
           guard (50...230).contains(height) else {
               showAlert(message: "Chiều cao phải từ 50 đến 230 cm.")
               BMIResult.text = "N/A"
               return
           }

           guard (16...200).contains(weight) else {
               showAlert(message: "Cân nặng phải từ 16 đến 200 kg.")
               BMIResult.text = "N/A"
               return
           }

           // Tính BMI nếu hợp lệ
           let heightInMeters = height / 100.0
           let bmi = weight / (heightInMeters * heightInMeters)
           let bmiRounded = String(format: "%.1f", bmi)
           BMIResult.text = bmiRounded
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Thông báo", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
